# Спасибо за подсказку, я недавно начал писать на python именно для интервью и алгоритмов и контестов.
# Не знал ещё про распаковку в Python, в JS только
# Просто для интереса, проверил производительность, 
# вообщем-то рад что print c join не медленнее, join гибче, можно через запятую, pipe и как хочется
# но спасибо за совет
import time

ar = [0]*10000

timePrint = 0
timeJoin = 0
for i in range(1000):
  # == calc print unpack
  startPrint = time.time()
  print(*ar)
  timePrint += time.time() - startPrint
  
  # == calc print join
  startJoin = time.time()
  print(" ".join(map(str, ar)))
  timeJoin += time.time() - startJoin

print("Time print join: %s sec" % timeJoin)
print("Time print unpack: %s sec" % timePrint)
print("Time join is faster on %s%%" % round((timePrint-timeJoin)/timePrint * 100,2))